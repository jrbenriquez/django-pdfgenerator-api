METHOD_URLS = {
    'view_templates': 'templates',
    'view_template': 'templates/{template}',
    'edit_template': 'templates/{template}/editor',
    'create_template': 'templates',
    'download_document': 'templates/{template}/output',
    'delete_template': 'templates/{template}'
}