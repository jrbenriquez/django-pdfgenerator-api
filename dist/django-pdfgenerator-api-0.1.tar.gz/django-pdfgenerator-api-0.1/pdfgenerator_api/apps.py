from django.apps import AppConfig


class PdfgeneratorApiConfig(AppConfig):
    name = 'pdfgenerator_api'
